import React from 'react';
import Action from '@webiny/app-page-builder/editor/plugins/elementSettings/components/Action';
import {PbEditorPageElementSettingsPlugin} from '@webiny/app-page-builder/types'
import Settings from "./settings";


export default {
    name: "pb-editor-page-element-settings-sizechange",
    type: "pb-editor-page-element-settings",
    renderAction() {
        return <Action tooltip={"TEST"} plugin={this.name} icon={"C"}/>
    },
    renderMenu() {
        return <Settings/>
    }
} as PbEditorPageElementSettingsPlugin;